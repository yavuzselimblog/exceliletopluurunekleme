<form action="yukle.php" method="POST" enctype="multipart/form-data">
<input type="file" name="excelFile" /><br>
<button type="submit" name="yolla">Toplu Ürün Yükle</button>
</form>