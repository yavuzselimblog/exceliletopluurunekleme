<?php 

ob_start();
$db = new PDO("mysql:host=localhost;dbname=excel;charset=utf8;","root","");

?>